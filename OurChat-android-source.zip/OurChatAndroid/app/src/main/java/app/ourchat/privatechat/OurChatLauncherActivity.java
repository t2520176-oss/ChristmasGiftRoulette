package app.ourchat.privatechat;

import android.net.Uri;

import com.google.androidbrowserhelper.trusted.LauncherActivity;

/** Opens OurChat and accepts deep links only within its HTTPS origin. */
public final class OurChatLauncherActivity extends LauncherActivity {
    @Override
    protected boolean isTrustedIntentUrl(Uri uri) {
        return uri != null
                && "https".equalsIgnoreCase(uri.getScheme())
                && "ourchat-lwnvrnlkdwjpfwnzugfr.vercel.app".equalsIgnoreCase(uri.getHost())
                && (uri.getPort() == -1 || uri.getPort() == 443)
                && uri.getUserInfo() == null;
    }
}
