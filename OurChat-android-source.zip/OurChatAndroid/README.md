# OurChat for Android

This Android app opens the existing OurChat HTTPS service through an installed, trusted browser using Android Browser Helper 2.7.4 (Trusted Web Activity). It does not embed a WebView or contain account credentials, message data, API secrets, or a server.

- Application ID: `app.ourchat.privatechat`
- Minimum Android: 7.0 (API 24, required by Android Browser Helper 2.7.4); compile/target SDK: 36
- Chrome or another browser supporting Trusted Web Activities must be installed and enabled.
- Internet access and an existing OurChat account are required.
- Home launches and incoming HTTPS deep links use only the configured OurChat origin. Other incoming URLs fall back to the home page.
- Notifications are enabled only when requested inside OurChat. Android 13+ may ask for notification permission. Android notification settings, Do Not Disturb, volume and battery policies control sound and popups.
- Before release, serve `assetlinks.json` as `https://ourchat-lwnvrnlkdwjpfwnzugfr.vercel.app/.well-known/assetlinks.json`. The package name and SHA-256 certificate fingerprint must match the signed APK.

## Build a release

Use JDK 17, Android SDK platform 36 and Build Tools 36.0.0. The Gradle wrapper pins Gradle 8.13 and checks its distribution SHA-256; the Android Gradle Plugin is pinned to 8.13.1.

Keep the release keystore and a properties file outside this source directory with `storeFile`, `storePassword`, `keyAlias` and `keyPassword`. Never publish either file. Set `OURCHAT_SIGNING_PROPERTIES` to that private properties file and `ANDROID_HOME` to your SDK, then run `./gradlew --no-daemon :app:assembleRelease :app:lintRelease` (Windows: `gradlew.bat`). The APK is generated at `app/build/outputs/apk/release/app-release.apk`.

The original release signing key must be retained privately for app updates. A replacement signing key requires updating the website's Digital Asset Links, and cannot update an existing installation signed with a different key. This source package contains only the public release certificate, `release-certificate.der`; its SHA-256 fingerprint is `3B:4E:97:8F:A2:67:C2:3E:C3:07:C7:B9:4C:09:2B:DF:23:CE:55:72:F8:61:BD:1E:E7:1B:35:B9:7B:9E:63:22`.

Install the downloaded release APK using Android's normal package installer. If prompted, allow installation for the browser or Files app being used. This is not a Play Store release, and Android/Play Protect may show sideloading or developer-verification warnings. Do not disable Play Protect or other device security to install it. If Android blocks installation, use the website's Add to Home screen installation instead.

Physical-device installation, verified fullscreen launch, browser delegation, message delivery and lock-screen notification behavior require testing on the receiving phone. Open the app with an updated TWA-capable browser installed, sign in, tap **Enable notifications**, and grant the requested browser/Android permission. Send a message from another account while the receiving app is backgrounded and while the phone is locked; confirm receipt, tap navigation, sound and popup behavior. Also check permission denial and re-enabling notifications in Android settings.
